# Third-party notices

This project bundles React 16.0.0 and ReactDOM 16.0.1 UMD builds as supplied with an installed Jupyter nbclassic distribution. These files are used solely to make the prototype runnable without a remote package registry.

React and ReactDOM Copyright (c) 2013-present, Facebook, Inc. Both are licensed under the MIT License:

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Game icons (v0.4)

The `public/icons/` artwork in this package was converted from `icons.rar` supplied by the user of this project. Names and icons are associated with Kingdom Come: Deliverance II and may be copyrighted by Warhorse Studios / the respective rights holders. This package does **not** claim that game artwork is available under an open-source license. The administrator should verify permission for public redistribution of the artwork on a public website or CDN before deploying these files.

File conversion uses WebP; image sources were not replaced with unrelated stock assets. React and the site's own code are separate from these game assets.
